class Usuario {
  final String ra;
  final String nome;
  final String senha;

  const Usuario(this.ra, this.nome, this.senha);
}